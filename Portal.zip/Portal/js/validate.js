function validate() {
  var Password = document.getElementById('password').value;
  if (Password == 'CAOneTechCloud') {
    // window.alert('Succesfully Logged In');
    window.location.href = '../main.html';
  } else {
    // window.alert('Password entered is wrong');
    document.getElementById('messeges').innerHTML = "**wrong password please try again..."



    

    return false ;
  }
}
